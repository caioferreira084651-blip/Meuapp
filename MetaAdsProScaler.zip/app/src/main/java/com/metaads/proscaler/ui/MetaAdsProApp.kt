@file:OptIn(ExperimentalMaterial3Api::class)

package com.metaads.proscaler.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.metaads.proscaler.model.AdsRowItem
import com.metaads.proscaler.viewmodel.MetaViewModel
import java.util.Locale

private val BgDark = Color(0xFF090D16)
private val CardDark = Color(0xFF111827)
private val BorderDark = Color(0xFF1F2937)
private val AccentBlue = Color(0xFF38BDF8)
private val AccentGreen = Color(0xFF10B981)
private val AccentRed = Color(0xFFEF4444)
private val AccentAmber = Color(0xFFF59E0B)
private val TextWhite = Color(0xFFF8FAFC)
private val TextGray = Color(0xFF94A3B8)

private val DarkColorPalette = darkColorScheme(
    primary = AccentBlue,
    secondary = AccentGreen,
    background = BgDark,
    surface = CardDark,
    onPrimary = Color.Black,
    onBackground = TextWhite,
    onSurface = TextWhite
)

@Composable
fun MetaAdsProApp(vm: MetaViewModel) {
    var currentBottomTab by remember { mutableStateOf(0) }
    var showQuickCreateAccountDialog by remember { mutableStateOf(false) }
    var showQuickCreatePixelDialog by remember { mutableStateOf(false) }
    var showDuplicateDialog by remember { mutableStateOf(false) }

    MaterialTheme(colorScheme = DarkColorPalette) {
        Scaffold(
            containerColor = BgDark,
            topBar = {
                TopHeaderBar(
                    vm = vm,
                    onQuickNewAccount = { showQuickCreateAccountDialog = true },
                    onQuickNewPixel = { showQuickCreatePixelDialog = true }
                )
            },
            bottomBar = {
                NavigationBar(containerColor = CardDark, tonalElevation = 8.dp) {
                    val tabs = listOf(
                        "📊 Planilha Pro",
                        "🚀 Subir Anúncio",
                        "🏢 BM & Pixels",
                        "🎯 Públicos & Regras"
                    )
                    tabs.forEachIndexed { index, label ->
                        NavigationBarItem(
                            selected = currentBottomTab == index,
                            onClick = { currentBottomTab = index },
                            icon = { Text(label.take(2), fontSize = 16.sp) },
                            label = { Text(label.drop(3), fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                        )
                    }
                }
            }
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .background(BgDark)
            ) {
                when (currentBottomTab) {
                    0 -> DesktopSpreadsheetScreen(
                        vm = vm,
                        onOpenDuplicateModal = { showDuplicateDialog = true }
                    )
                    1 -> FullDesktopCampaignCreatorScreen(
                        vm = vm,
                        onPublished = { currentBottomTab = 0 }
                    )
                    2 -> BmAndPixelFactoryScreen(vm = vm)
                    3 -> AudiencesAndRulesScreen(vm = vm)
                }
            }
        }

        if (showQuickCreateAccountDialog) {
            QuickCreateAccountModal(
                vm = vm,
                onDismiss = { showQuickCreateAccountDialog = false }
            )
        }

        if (showQuickCreatePixelDialog) {
            QuickCreatePixelModal(
                vm = vm,
                onDismiss = { showQuickCreatePixelDialog = false }
            )
        }

        if (showDuplicateDialog) {
            Duplicate1ToNModal(
                selectedCount = vm.selectedRowIds.size,
                onDismiss = { showDuplicateDialog = false },
                onConfirm = { copies ->
                    vm.duplicateSelected1ToN(copies)
                    showDuplicateDialog = false
                }
            )
        }
    }
}

@Composable
fun TopHeaderBar(
    vm: MetaViewModel,
    onQuickNewAccount: () -> Unit,
    onQuickNewPixel: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(CardDark)
            .padding(horizontal = 12.dp, vertical = 8.dp)
    ) {
        // Linha 1: Seletor de Perfil + BM + Conta + Botoes 1-Clique
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Troca de Perfil do Facebook em 1 toque
            Surface(
                color = Color(0xFF1E293B),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.clickable {
                    val idx = (vm.profiles.indexOf(vm.selectedProfile) + 1) % vm.profiles.size
                    vm.selectedProfile = vm.profiles[idx]
                    vm.statusBanner = "Alternado para ${vm.selectedProfile.name}"
                }
            ) {
                Text(
                    text = "👤 ${vm.selectedProfile.name}",
                    color = AccentBlue,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                )
            }

            // Troca de BM em 1 toque
            Surface(
                color = Color(0xFF1E293B),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.clickable {
                    val idx = (vm.businessManagers.indexOf(vm.selectedBm) + 1) % vm.businessManagers.size
                    vm.selectedBm = vm.businessManagers[idx]
                    vm.statusBanner = "BM Ativa: ${vm.selectedBm.name}"
                }
            ) {
                Text(
                    text = "🏢 ${vm.selectedBm.name}",
                    color = TextWhite,
                    fontSize = 12.sp,
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                )
            }

            // Troca de Conta de Anuncios em 1 toque
            Surface(
                color = Color(0xFF064E3B),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.clickable {
                    val idx = (vm.adAccounts.indexOf(vm.selectedAdAccount) + 1) % vm.adAccounts.size
                    vm.selectedAdAccount = vm.adAccounts[idx]
                    vm.statusBanner = "Conta Ativa: ${vm.selectedAdAccount.name}"
                }
            ) {
                Text(
                    text = "💳 ${vm.selectedAdAccount.name} (${vm.selectedAdAccount.actId})",
                    color = AccentGreen,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                )
            }

            Button(
                onClick = onQuickNewAccount,
                colors = ButtonDefaults.buttonColors(containerColor = AccentBlue),
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                modifier = Modifier.height(30.dp)
            ) {
                Text("+ Conta 1-Click", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.Black)
            }

            Button(
                onClick = onQuickNewPixel,
                colors = ButtonDefaults.buttonColors(containerColor = AccentGreen),
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                modifier = Modifier.height(30.dp)
            ) {
                Text("+ Pixel 1-Click", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.Black)
            }
        }

        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = "⚡ ${vm.statusBanner}",
            color = AccentAmber,
            fontSize = 11.sp,
            maxLines = 1
        )
    }
}

@Composable
fun DesktopSpreadsheetScreen(
    vm: MetaViewModel,
    onOpenDuplicateModal: () -> Unit
) {
    val filteredRows = vm.rows.filter { it.level == vm.selectedLevel }
    val totalSpend = filteredRows.sumOf { it.spend }
    val totalRev = filteredRows.sumOf { it.revenue }
    val totalPurchases = filteredRows.sumOf { it.purchases }
    val globalRoas = if (totalSpend > 0) totalRev / totalSpend else 0.0
    val globalCpa = if (totalPurchases > 0) totalSpend / totalPurchases else 0.0

    Column(modifier = Modifier.fillMaxSize().padding(10.dp)) {
        // Cards Resumo Financeiro
        Row(
            modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            MetricSummaryBadge("Gasto Total", fmtCurrency(totalSpend), TextWhite)
            MetricSummaryBadge("Faturamento", fmtCurrency(totalRev), AccentGreen)
            MetricSummaryBadge("ROAS Médio", String.format(Locale.US, "%.2fx", globalRoas), if (globalRoas >= 2.0) AccentGreen else AccentAmber)
            MetricSummaryBadge("Compras", totalPurchases.toString(), AccentBlue)
            MetricSummaryBadge("CPA Médio", fmtCurrency(globalCpa), TextWhite)
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Abas Hierarquicas estilo Computador (Campanhas > Conjuntos > Anuncios) + Filtros
        Row(
            modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            LevelTabButton("Campanhas", vm.selectedLevel == "CAMPAIGN") { vm.selectedLevel = "CAMPAIGN" }
            LevelTabButton("Conjuntos de Anúncios", vm.selectedLevel == "ADSET") { vm.selectedLevel = "ADSET" }
            LevelTabButton("Anúncios", vm.selectedLevel == "AD") { vm.selectedLevel = "AD" }

            Spacer(modifier = Modifier.width(8.dp))

            // Filtro de Datas
            listOf("Hoje", "Ontem", "7 Dias", "Máximo").forEach { preset ->
                FilterChip(
                    selected = vm.selectedDatePreset == preset,
                    onClick = { vm.selectedDatePreset = preset },
                    label = { Text(preset, fontSize = 11.sp) }
                )
            }

            // Detalhamento (Breakdowns)
            listOf("Nenhum", "Posicionamento", "Idade").forEach { bd ->
                FilterChip(
                    selected = vm.selectedBreakdown == bd,
                    onClick = { vm.selectedBreakdown = bd },
                    label = { Text("Detalhar: $bd", fontSize = 11.sp) }
                )
            }
        }

        // Barra de Acao em Massa (Bulk Engine) quando ha itens selecionados
        if (vm.selectedRowIds.isNotEmpty()) {
            Spacer(modifier = Modifier.height(6.dp))
            Surface(
                color = Color(0xFF1E3A8A),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                        .horizontalScroll(rememberScrollState()),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        "${vm.selectedRowIds.size} selecionados",
                        color = TextWhite,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )
                    Button(
                        onClick = onOpenDuplicateModal,
                        colors = ButtonDefaults.buttonColors(containerColor = AccentGreen),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),
                        modifier = Modifier.height(30.dp)
                    ) {
                        Text("Duplicar 1-N", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                    }
                    Button(
                        onClick = { vm.bulkAdjustBudgetPercent(20.0) },
                        colors = ButtonDefaults.buttonColors(containerColor = AccentBlue),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),
                        modifier = Modifier.height(30.dp)
                    ) {
                        Text("Orçamento +20%", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                    }
                    Button(
                        onClick = { vm.bulkAdjustBudgetPercent(-20.0) },
                        colors = ButtonDefaults.buttonColors(containerColor = AccentAmber),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),
                        modifier = Modifier.height(30.dp)
                    ) {
                        Text("Orçamento -20%", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                    }
                    Button(
                        onClick = { vm.bulkSetStatus( false) },
                        colors = ButtonDefaults.buttonColors(containerColor = AccentRed),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),
                        modifier = Modifier.height(30.dp)
                    ) {
                        Text("Pausar Lote", color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                    }
                    Button(
                        onClick = { vm.bulkSetStatus(true) },
                        colors = ButtonDefaults.buttonColors(containerColor = CardDark),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),
                        modifier = Modifier.height(30.dp)
                    ) {
                        Text("Ativar Lote", color = TextWhite, fontSize = 11.sp)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Tabela Planilha Desktop com Rolagem Horizontal e Vertical
        val hScroll = rememberScrollState()
        Column(
            modifier = Modifier
                .fillMaxSize()
                .border(1.dp, BorderDark, RoundedCornerShape(8.dp))
                .background(CardDark, RoundedCornerShape(8.dp))
        ) {
            // Cabecalho da Planilha
            Row(
                modifier = Modifier
                    .background(Color(0xFF1E293B))
                    .horizontalScroll(hScroll)
                    .padding(vertical = 8.dp, horizontal = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Checkbox(
                    checked = filteredRows.isNotEmpty() && vm.selectedRowIds.containsAll(filteredRows.map { it.id }),
                    onCheckedChange = { vm.selectAllCurrentLevel() },
                    modifier = Modifier.size(28.dp)
                )
                TableHeaderCell("Status", 70.dp)
                TableHeaderCell("Nome / Estrutura", 240.dp)
                TableHeaderCell("Tipo / Lance", 120.dp)
                TableHeaderCell("Orçamento", 100.dp)
                TableHeaderCell("Gasto", 100.dp)
                TableHeaderCell("Compras", 80.dp)
                TableHeaderCell("CPA", 95.dp)
                TableHeaderCell("ROAS", 85.dp)
                TableHeaderCell("Faturamento", 110.dp)
                TableHeaderCell("IC (Checkout)", 100.dp)
                TableHeaderCell("Hook Rate (3s)", 110.dp)
                TableHeaderCell("Hold Rate", 95.dp)
                TableHeaderCell("CTR (Link)", 90.dp)
                TableHeaderCell("CPM", 90.dp)
                TableHeaderCell("Post ID / UTMs", 220.dp)
            }

            Divider(color = BorderDark)

            LazyColumn(modifier = Modifier.fillMaxSize()) {
                items(filteredRows, key = { it.id }) { row ->
                    DesktopDataRow(
                        row = row,
                        isSelected = vm.selectedRowIds.contains(row.id),
                        breakdownMode = vm.selectedBreakdown,
                        hScroll = hScroll,
                        onSelectToggle = { vm.toggleRowSelection(row.id) },
                        onStatusToggle = { vm.toggleRowStatus(row.id) }
                    )
                    Divider(color = BorderDark)
                }
            }
        }
    }
}

@Composable
fun DesktopDataRow(
    row: AdsRowItem,
    isSelected: Boolean,
    breakdownMode: String,
    hScroll: androidx.compose.foundation.ScrollState,
    onSelectToggle: () -> Unit,
    onStatusToggle: () -> Unit
) {
    Column {
        Row(
            modifier = Modifier
                .background(if (isSelected) Color(0xFF172554) else CardDark)
                .horizontalScroll(hScroll)
                .padding(vertical = 8.dp, horizontal = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Checkbox(
                checked = isSelected,
                onCheckedChange = { onSelectToggle() },
                modifier = Modifier.size(28.dp)
            )
            Box(modifier = Modifier.width(70.dp)) {
                Switch(
                    checked = row.active,
                    onCheckedChange = { onStatusToggle() }
                )
            }
            Text(
                text = row.name,
                color = TextWhite,
                fontWeight = FontWeight.SemiBold,
                fontSize = 13.sp,
                modifier = Modifier.width(240.dp).padding(end = 8.dp)
            )
            Text(
                text = "${row.budgetType} • ${row.bidStrategy}",
                color = AccentBlue,
                fontSize = 11.sp,
                modifier = Modifier.width(120.dp)
            )
            TableValueCell(fmtCurrency(row.dailyBudget), 100.dp, TextWhite)
            TableValueCell(fmtCurrency(row.spend), 100.dp, TextWhite)
            TableValueCell(row.purchases.toString(), 80.dp, AccentBlue, bold = true)
            TableValueCell(fmtCurrency(row.cpa), 95.dp, TextWhite)
            TableValueCell(
                String.format(Locale.US, "%.2fx", row.roas),
                85.dp,
                if (row.roas >= 2.0) AccentGreen else if (row.roas < 1.0 && row.spend > 0) AccentRed else AccentAmber,
                bold = true
            )
            TableValueCell(fmtCurrency(row.revenue), 110.dp, AccentGreen)
            TableValueCell(row.initiateCheckouts.toString(), 100.dp, TextWhite)
            TableValueCell(String.format(Locale.US, "%.1f%%", row.hookRate), 110.dp, if (row.hookRate >= 30.0) AccentGreen else TextWhite)
            TableValueCell(String.format(Locale.US, "%.1f%%", row.holdRate), 95.dp, TextWhite)
            TableValueCell(String.format(Locale.US, "%.2f%%", row.ctr), 90.dp, TextWhite)
            TableValueCell(fmtCurrency(row.cpm), 90.dp, TextGray)
            Text(
                text = if (row.postId.isNotBlank()) "PostID: ${row.postId}" else row.utmParams,
                color = TextGray,
                fontSize = 11.sp,
                maxLines = 1,
                modifier = Modifier.width(220.dp)
            )
        }

        // Sub-linhas automaticas se o usuario ativar o Detalhamento (Breakdown)
        if (breakdownMode == "Posicionamento") {
            BreakdownSubRow("↳ Instagram Reels", fmtCurrency(row.spend * 0.62), "${(row.purchases * 0.72).toInt()} vendas", "ROAS ${(row.roas * 1.18).let { String.format(Locale.US, "%.2fx", it) }}", hScroll)
            BreakdownSubRow("↳ Instagram Stories", fmtCurrency(row.spend * 0.25), "${(row.purchases * 0.20).toInt()} vendas", "ROAS ${(row.roas * 0.85).let { String.format(Locale.US, "%.2fx", it) }}", hScroll)
            BreakdownSubRow("↳ Facebook Feed", fmtCurrency(row.spend * 0.13), "${(row.purchases * 0.08).toInt()} vendas", "ROAS ${(row.roas * 0.65).let { String.format(Locale.US, "%.2fx", it) }}", hScroll)
        } else if (breakdownMode == "Idade") {
            BreakdownSubRow("↳ 25-34 anos", fmtCurrency(row.spend * 0.48), "${(row.purchases * 0.55).toInt()} vendas", "ROAS ${(row.roas * 1.15).let { String.format(Locale.US, "%.2fx", it) }}", hScroll)
            BreakdownSubRow("↳ 35-44 anos", fmtCurrency(row.spend * 0.35), "${(row.purchases * 0.35).toInt()} vendas", "ROAS ${String.format(Locale.US, "%.2fx", row.roas)}", hScroll)
        }
    }
}

@Composable
fun BreakdownSubRow(label: String, spend: String, sales: String, roas: String, hScroll: androidx.compose.foundation.ScrollState) {
    Row(
        modifier = Modifier
            .background(Color(0xFF0B1324))
            .horizontalScroll(hScroll)
            .padding(vertical = 4.dp, horizontal = 40.dp),
        horizontalArrangement = Arrangement.spacedBy(24.dp)
    ) {
        Text(label, color = AccentBlue, fontSize = 11.sp, modifier = Modifier.width(200.dp))
        Text("Gasto: $spend", color = TextGray, fontSize = 11.sp)
        Text(sales, color = AccentGreen, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        Text(roas, color = AccentAmber, fontSize = 11.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun FullDesktopCampaignCreatorScreen(vm: MetaViewModel, onPublished: () -> Unit) {
    var campaignName by remember { mutableStateOf("[ESC] [CBO] Produto Campeão - Escala") }
    var isCbo by remember { mutableStateOf(true) }
    var bidStrategy by remember { mutableStateOf("VOLUME_MAIS_ALTO") }
    var budgetText by remember { mutableStateOf("1000.00") }
    var minSpendCbo by remember { mutableStateOf("") }
    var maxSpendCbo by remember { mutableStateOf("") }

    var adSetName by remember { mutableStateOf("01 - Aberto Advantage+ [Reels/Stories]") }
    var copiesCountText by remember { mutableStateOf("5") }
    var placementMode by remember { mutableStateOf("Advantage+ Automático") }

    var creativeMode by remember { mutableStateOf("DARK_POST") } // DARK_POST, CRIAR_NOVO, DCO
    var adName by remember { mutableStateOf("AD01 - VSL Campeã [Dark Post]") }
    var postId by remember { mutableStateOf("122148992031_99817263541") }
    var destinationUrl by remember { mutableStateOf("https://seuproduto.com.br/oferta") }
    var utmParams by remember {
        mutableStateOf("utm_source=FB&utm_medium={{adset.name}}&utm_campaign={{campaign.name}}&utm_content={{ad.name}}&utm_term={{placement}}")
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("🚀 Criador Completo de Escala (Fluxo em 1 Tela)", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = AccentBlue)

        // BLOCO 1: CAMPANHA
        Surface(color = CardDark, shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("1. Nível de Campanha (ODAX Vendas)", fontWeight = FontWeight.Bold, color = AccentGreen)
                OutlinedTextField(
                    value = campaignName,
                    onValueChange = { campaignName = it },
                    label = { Text("Nome da Campanha") },
                    modifier = Modifier.fillMaxWidth()
                )
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Orçamento Advantage+ (CBO):", color = TextWhite)
                    Switch(checked = isCbo, onCheckedChange = { isCbo = it })
                    Text(if (isCbo) "CBO Ativo" else "ABO (Por Conjunto)", color = AccentBlue, fontWeight = FontWeight.Bold)
                }
                Text("Estratégia de Lance:", fontSize = 12.sp, color = TextGray)
                Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("VOLUME_MAIS_ALTO", "COST_CAP", "BID_CAP", "ROAS_MINIMO").forEach { strat ->
                        FilterChip(
                            selected = bidStrategy == strat,
                            onClick = { bidStrategy = strat },
                            label = { Text(strat, fontSize = 11.sp) }
                        )
                    }
                }
                OutlinedTextField(
                    value = budgetText,
                    onValueChange = { budgetText = it },
                    label = { Text("Orçamento Diário (R$)") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }

        // BLOCO 2: CONJUNTO DE ANUNCIOS + MULTIPLICADOR 1-N
        Surface(color = CardDark, shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("2. Conjunto de Anúncios + Multiplicador 1-para-N", fontWeight = FontWeight.Bold, color = AccentGreen)
                OutlinedTextField(
                    value = adSetName,
                    onValueChange = { adSetName = it },
                    label = { Text("Nome do Conjunto de Anúncios") },
                    modifier = Modifier.fillMaxWidth()
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = copiesCountText,
                        onValueChange = { copiesCountText = it },
                        label = { Text("Quantas cópias subir? (Ex: 10)") },
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = minSpendCbo,
                        onValueChange = { minSpendCbo = it },
                        label = { Text("Gasto Mín CBO (Opcional)") },
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = maxSpendCbo,
                        onValueChange = { maxSpendCbo = it },
                        label = { Text("Gasto Máx CBO") },
                        modifier = Modifier.weight(1f)
                    )
                }
                Text("Posicionamentos:", fontSize = 12.sp, color = TextGray)
                Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("Advantage+ Automático", "Manual: Só Reels + Stories", "Manual: Só Feed").forEach { pos ->
                        FilterChip(
                            selected = placementMode == pos,
                            onClick = { placementMode = pos },
                            label = { Text(pos, fontSize = 11.sp) }
                        )
                    }
                }
            }
        }

        // BLOCO 3: ANUNCIO (POST ID / DARK POST / DCO + CONSTRUTOR DE UTMS)
        Surface(color = CardDark, shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("3. Anúncio, Post ID (Prova Social) e Rastreamento UTM", fontWeight = FontWeight.Bold, color = AccentGreen)
                Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = creativeMode == "DARK_POST",
                        onClick = { creativeMode = "DARK_POST" },
                        label = { Text("Usar Publicação Existente (Post ID)") }
                    )
                    FilterChip(
                        selected = creativeMode == "DCO",
                        onClick = { creativeMode = "DCO" },
                        label = { Text("Criativo Dinâmico (DCO 10x)") }
                    )
                    FilterChip(
                        selected = creativeMode == "CRIAR_NOVO",
                        onClick = { creativeMode = "CRIAR_NOVO" },
                        label = { Text("Upload Vídeo/Imagem") }
                    )
                }

                OutlinedTextField(
                    value = adName,
                    onValueChange = { adName = it },
                    label = { Text("Nome do Anúncio") },
                    modifier = Modifier.fillMaxWidth()
                )

                if (creativeMode == "DARK_POST") {
                    OutlinedTextField(
                        value = postId,
                        onValueChange = { postId = it },
                        label = { Text("Identificação da Publicação (Post ID) — Mantém Curtidas e Comentários") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                OutlinedTextField(
                    value = destinationUrl,
                    onValueChange = { destinationUrl = it },
                    label = { Text("URL do Site / Página de Vendas") },
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = utmParams,
                    onValueChange = { utmParams = it },
                    label = { Text("Parâmetros de URL (UTMs Dinâmicas)") },
                    modifier = Modifier.fillMaxWidth()
                )

                Button(
                    onClick = {
                        val b = budgetText.toDoubleOrNull() ?: 500.0
                        val c = copiesCountText.toIntOrNull() ?: 1
                        vm.publishFullStructure(
                            campaignName = campaignName,
                            budgetType = if (isCbo) "CBO" else "ABO",
                            bidStrategy = bidStrategy,
                            dailyBudget = b,
                            adSetName = adSetName,
                            adSetCopies = c,
                            adName = adName,
                            postId = if (creativeMode == "DARK_POST") postId else "",
                            utmString = utmParams
                        )
                        onPublished()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = AccentGreen),
                    modifier = Modifier.fillMaxWidth().height(52.dp)
                ) {
                    Text(
                        "PUBLICAR ESTRUTURA DE ESCALA AGORA (1-${copiesCountText.ifBlank { "1" }}-${copiesCountText.ifBlank { "1" }})",
                        color = Color.Black,
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 14.sp
                    )
                }
            }
        }
    }
}

@Composable
fun BmAndPixelFactoryScreen(vm: MetaViewModel) {
    val clipboard = LocalClipboardManager.current
    var newProfileName by remember { mutableStateOf("") }
    var newProfileToken by remember { mutableStateOf("") }
    var newAccName by remember { mutableStateOf("") }
    var newPixelName by remember { mutableStateOf("") }

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Modulo 1: Cofre Multi-Perfis do Facebook
        item {
            Surface(color = CardDark, shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("👤 Cofre Multi-Perfis do Facebook (Contingência)", fontWeight = FontWeight.Bold, color = AccentBlue, fontSize = 16.sp)
                    Text("Conecte várias contas de Facebook e alterne no topo do app sem deslogar.", color = TextGray, fontSize = 12.sp)
                    OutlinedTextField(
                        value = newProfileName,
                        onValueChange = { newProfileName = it },
                        label = { Text("Nome do Perfil (Ex: Perfil 03 - Contingência)") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = newProfileToken,
                        onValueChange = { newProfileToken = it },
                        label = { Text("Token de Acesso Graph API (EAAB... ou deixe vazio para Simulação)") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Button(
                        onClick = {
                            vm.addFacebookProfile(newProfileName, newProfileToken)
                            newProfileName = ""
                            newProfileToken = ""
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = AccentBlue),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("CONECTAR NOVO PERFIL DE FACEBOOK", color = Color.Black, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Modulo 2: Fabrica de Contas de Anuncio em 1 Clique
        item {
            Surface(color = CardDark, shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("💳 Fábrica de Contas de Anúncio em 1 Clique", fontWeight = FontWeight.Bold, color = AccentGreen, fontSize = 16.sp)
                    Text("Moeda BRL e Fuso America/Sao_Paulo pré-configurados + Atribuição Automática de Admin.", color = TextGray, fontSize = 12.sp)
                    OutlinedTextField(
                        value = newAccName,
                        onValueChange = { newAccName = it },
                        label = { Text("Nome da Nova Conta de Anúncios") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Button(
                        onClick = {
                            vm.createNewAdAccount1Click(newAccName, "BRL", "America/Sao_Paulo")
                            newAccName = ""
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = AccentGreen),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("CRIAR CONTA + DAR PERMISSÃO ADMIN AUTOMÁTICA", color = Color.Black, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Modulo 3: Fabrica de Pixel + CAPI em 1 Clique
        item {
            Surface(color = CardDark, shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("⚡ Fábrica de Pixel + API de Conversões (Vínculo Automático)", fontWeight = FontWeight.Bold, color = AccentAmber, fontSize = 16.sp)
                    OutlinedTextField(
                        value = newPixelName,
                        onValueChange = { newPixelName = it },
                        label = { Text("Nome do Novo Pixel (Será vinculado à ${vm.selectedAdAccount.name})") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Button(
                        onClick = {
                            vm.createNewPixel1Click(newPixelName)
                            newPixelName = ""
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = AccentAmber),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("CRIAR PIXEL + VINCULAR À CONTA + GERAR CAPI", color = Color.Black, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Lista de Pixels Ativos com Botao de Copiar em 1 Clique
        items(vm.pixels, key = { it.id }) { px ->
            Surface(color = Color(0xFF1E293B), shape = RoundedCornerShape(10.dp), modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("🎯 ${px.name}", fontWeight = FontWeight.Bold, color = TextWhite)
                    Text("ID do Pixel: ${px.id} • Conta Vinculada: ${px.linkedAccountId}", color = AccentBlue, fontSize = 12.sp)
                    Text("Qualidade de Correspondência (EMQ): ${px.matchQuality}/10 • ${px.lastEvents}", color = AccentGreen, fontSize = 11.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = {
                                clipboard.setText(AnnotatedString(px.id))
                                vm.statusBanner = "ID do Pixel ${px.id} copiado!"
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = AccentBlue),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Copiar Pixel ID", color = Color.Black, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                        Button(
                            onClick = {
                                clipboard.setText(AnnotatedString(px.capiToken))
                                vm.statusBanner = "Token CAPI copiado para a área de transferência!"
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = AccentGreen),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Copiar Token CAPI", color = Color.Black, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AudiencesAndRulesScreen(vm: MetaViewModel) {
    var audName by remember { mutableStateOf("") }
    var audType by remember { mutableStateOf("LOOKALIKE") }

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Surface(color = CardDark, shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("🎯 Criar Público Personalizado ou Lookalike (1% a 10%)", fontWeight = FontWeight.Bold, color = AccentBlue, fontSize = 16.sp)
                    Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("LOOKALIKE 1%", "LOOKALIKE 1%-3%", "PIXEL PURCHASE 180D", "IG ENGAJAMENTO 365D", "VÍDEO 75%").forEach { t ->
                            FilterChip(
                                selected = audType == t,
                                onClick = { audType = t },
                                label = { Text(t, fontSize = 11.sp) }
                            )
                        }
                    }
                    OutlinedTextField(
                        value = audName,
                        onValueChange = { audName = it },
                        label = { Text("Nome do Público") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Button(
                        onClick = {
                            vm.createAudience(audName.ifBlank { "Público $audType" }, audType, audType)
                            audName = ""
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = AccentBlue),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("CRIAR PÚBLICO NA CONTA ATIVA", color = Color.Black, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        item {
            Text("🤖 Piloto Automático (Regras de Proteção e Escala)", fontWeight = FontWeight.Bold, color = AccentGreen, fontSize = 16.sp)
        }

        items(vm.automatedRules, key = { it.id }) { rule ->
            Surface(color = CardDark, shape = RoundedCornerShape(10.dp), modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier.padding(12.dp).fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(rule.name, fontWeight = FontWeight.Bold, color = TextWhite, fontSize = 14.sp)
                        Text("Condição: ${rule.conditionText}", color = AccentAmber, fontSize = 12.sp)
                        Text("Ação: ${rule.actionText}", color = AccentGreen, fontSize = 12.sp)
                    }
                    Switch(checked = rule.enabled, onCheckedChange = { vm.toggleRule(rule.id) })
                }
            }
        }

        item {
            Text("👥 Públicos Ativos na Conta", fontWeight = FontWeight.Bold, color = TextWhite, fontSize = 15.sp)
        }

        items(vm.audiences, key = { it.id }) { aud ->
            Surface(color = Color(0xFF1E293B), shape = RoundedCornerShape(8.dp), modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier.padding(12.dp).fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text(aud.name, fontWeight = FontWeight.Bold, color = TextWhite)
                        Text("${aud.type} • ${aud.subtype}", color = AccentBlue, fontSize = 12.sp)
                    }
                    Text(aud.sizeEstimate, color = AccentGreen, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun QuickCreateAccountModal(vm: MetaViewModel, onDismiss: () -> Unit) {
    var name by remember { mutableStateOf("CA Nova Escala [BRL]") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Nova Conta de Anúncios em 1 Clique") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("BM: ${vm.selectedBm.name}\nMoeda: BRL (Real)\nFuso: America/Sao_Paulo\nPermissão Admin: Automática", fontSize = 12.sp, color = TextGray)
                OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Nome da Conta") })
            }
        },
        confirmButton = {
            Button(onClick = { vm.createNewAdAccount1Click(name, "BRL", "America/Sao_Paulo"); onDismiss() }) {
                Text("Criar Agora")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancelar") }
        }
    )
}

@Composable
fun QuickCreatePixelModal(vm: MetaViewModel, onDismiss: () -> Unit) {
    var name by remember { mutableStateOf("Pixel Escala Oferta") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Criar + Vincular Pixel em 1 Clique") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Será criado na ${vm.selectedBm.name} e vinculado automaticamente à ${vm.selectedAdAccount.name}.", fontSize = 12.sp, color = TextGray)
                OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Nome do Pixel") })
            }
        },
        confirmButton = {
            Button(onClick = { vm.createNewPixel1Click(name); onDismiss() }) {
                Text("Criar e Gerar CAPI")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancelar") }
        }
    )
}

@Composable
fun Duplicate1ToNModal(selectedCount: Int, onDismiss: () -> Unit, onConfirm: (Int) -> Unit) {
    var copiesText by remember { mutableStateOf("10") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Duplicação Avançada 1-para-N") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Itens selecionados: $selectedCount\nMantém Post ID (curtidas e comentários) automaticamente.", fontSize = 12.sp, color = TextGray)
                OutlinedTextField(
                    value = copiesText,
                    onValueChange = { copiesText = it },
                    label = { Text("Quantidade de Cópias (1 a 50)") }
                )
            }
        },
        confirmButton = {
            Button(onClick = { onConfirm(copiesText.toIntOrNull() ?: 5) }) {
                Text("Publicar Cópias")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancelar") }
        }
    )
}

@Composable
fun MetricSummaryBadge(title: String, value: String, valueColor: Color) {
    Surface(
        color = CardDark,
        shape = RoundedCornerShape(8.dp),
        modifier = Modifier.border(1.dp, BorderDark, RoundedCornerShape(8.dp))
    ) {
        Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)) {
            Text(title, color = TextGray, fontSize = 10.sp)
            Text(value, color = valueColor, fontWeight = FontWeight.ExtraBold, fontSize = 14.sp)
        }
    }
}

@Composable
fun LevelTabButton(text: String, selected: Boolean, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        colors = ButtonDefaults.buttonColors(
            containerColor = if (selected) AccentBlue else CardDark
        ),
        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
        modifier = Modifier.height(34.dp)
    ) {
        Text(
            text = text,
            color = if (selected) Color.Black else TextWhite,
            fontWeight = FontWeight.Bold,
            fontSize = 12.sp
        )
    }
}

@Composable
fun TableHeaderCell(text: String, width: androidx.compose.ui.unit.Dp) {
    Text(
        text = text,
        color = AccentBlue,
        fontWeight = FontWeight.Bold,
        fontSize = 11.sp,
        modifier = Modifier.width(width)
    )
}

@Composable
fun TableValueCell(text: String, width: androidx.compose.ui.unit.Dp, color: Color, bold: Boolean = false) {
    Text(
        text = text,
        color = color,
        fontWeight = if (bold) FontWeight.Bold else FontWeight.Normal,
        fontSize = 12.sp,
        modifier = Modifier.width(width)
    )
}

private fun fmtCurrency(v: Double): String = String.format(Locale.US, "R$ %.2f", v)
