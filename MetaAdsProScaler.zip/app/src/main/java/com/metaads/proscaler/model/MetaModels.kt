package com.metaads.proscaler.model

data class FbProfile(
    val id: String,
    val name: String,
    val accessToken: String,
    val status: String = "CONECTADO"
)

data class BusinessManager(
    val id: String,
    val name: String,
    val profileId: String
)

data class AdAccount(
    val id: String,
    val actId: String,
    val name: String,
    val bmId: String,
    val currency: String = "BRL",
    val timezone: String = "America/Sao_Paulo",
    val status: String = "ATIVA",
    val dailySpendLimit: Double = 25000.0,
    val currentBalance: Double = 0.0
)

data class AdPixel(
    val id: String,
    val name: String,
    val linkedAccountId: String,
    val capiToken: String,
    val matchQuality: Double = 9.3,
    val lastEvents: String = "PageView, InitiateCheckout, Purchase (Ativo)"
)

data class AdsRowItem(
    val id: String,
    val parentId: String,
    val level: String, // CAMPAIGN, ADSET, AD
    val name: String,
    val active: Boolean,
    val budgetType: String, // CBO, ABO
    val bidStrategy: String, // VOLUME_MAIS_ALTO, COST_CAP, BID_CAP, ROAS_MINIMO
    val dailyBudget: Double,
    val spend: Double,
    val purchases: Int,
    val revenue: Double,
    val initiateCheckouts: Int,
    val impressions: Int,
    val linkClicks: Int,
    val video3sViews: Int,
    val thruPlays: Int,
    val postId: String = "",
    val utmParams: String = "utm_source=FB&utm_medium={{adset.name}}&utm_campaign={{campaign.name}}&utm_content={{ad.name}}"
) {
    val cpa: Double get() = if (purchases > 0) spend / purchases else 0.0
    val roas: Double get() = if (spend > 0) revenue / spend else 0.0
    val cpm: Double get() = if (impressions > 0) (spend / impressions) * 1000.0 else 0.0
    val ctr: Double get() = if (impressions > 0) (linkClicks.toDouble() / impressions) * 100.0 else 0.0
    val cpc: Double get() = if (linkClicks > 0) spend / linkClicks else 0.0
    val hookRate: Double get() = if (impressions > 0) (video3sViews.toDouble() / impressions) * 100.0 else 0.0
    val holdRate: Double get() = if (impressions > 0) (thruPlays.toDouble() / impressions) * 100.0 else 0.0
}

data class CustomAudienceItem(
    val id: String,
    val name: String,
    val type: String, // PIXEL, INSTAGRAM, VIDEO, LOOKALIKE
    val subtype: String,
    val sizeEstimate: String
)

data class AutomatedRuleItem(
    val id: String,
    val name: String,
    val conditionText: String,
    val actionText: String,
    val enabled: Boolean
)
