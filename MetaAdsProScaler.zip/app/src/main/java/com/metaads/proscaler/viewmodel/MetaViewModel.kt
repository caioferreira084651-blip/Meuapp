package com.metaads.proscaler.viewmodel

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.metaads.proscaler.model.*
import com.metaads.proscaler.network.MetaApiService
import kotlinx.coroutines.launch

class MetaViewModel : ViewModel() {
    private val api = MetaApiService()

    // Status global / feedback rapido
    var statusBanner by mutableStateOf("Pronto para Escala • Paridade Desktop V2.0 Ativa")

    // 1. Cofre Multi-Perfis do Facebook (Contingencia)
    val profiles = mutableStateListOf(
        FbProfile("PRF_1", "Perfil 01 • Contingência Blindada", "DEMO_TOKEN_PRF1"),
        FbProfile("PRF_2", "Perfil 02 • BM Matriz Escala", "DEMO_TOKEN_PRF2")
    )
    var selectedProfile by mutableStateOf(profiles.first())

    // 2. Business Managers (BMs)
    val businessManagers = mutableStateListOf(
        BusinessManager("BM_901823", "BM 01 - Escala Infoprodutos & E-com", "PRF_1"),
        BusinessManager("BM_774120", "BM 02 - Contingência Oferta Direta", "PRF_1"),
        BusinessManager("BM_551900", "BM 03 - Internacional High Ticket", "PRF_2")
    )
    var selectedBm by mutableStateOf(businessManagers.first())

    // 3. Contas de Anuncio
    val adAccounts = mutableStateListOf(
        AdAccount("10492811", "act_10492811", "CA 01 - Escala CBO [BRL]", "BM_901823", "BRL", "America/Sao_Paulo", "ATIVA", 50000.0, 420.50),
        AdAccount("10492822", "act_10492822", "CA 02 - Teste Criativos ABO [BRL]", "BM_901823", "BRL", "America/Sao_Paulo", "ATIVA", 15000.0, 185.00),
        AdAccount("88392011", "act_88392011", "CA 03 - Backup Escala [BRL]", "BM_774120", "BRL", "America/Sao_Paulo", "ATIVA", 30000.0, 0.0)
    )
    var selectedAdAccount by mutableStateOf(adAccounts.first())

    // 4. Pixels & API de Conversoes (CAPI)
    val pixels = mutableStateListOf(
        AdPixel("847291038471920", "Pixel Oferta Principal - Vendas", "act_10492811", "EAABsbCS1iHgBO99CAPI7728192TokenProScaler", 9.4),
        AdPixel("552910448192011", "Pixel Backup Contingência", "act_10492822", "EAABsbCS1iHgBO88CAPI1129384TokenBackup", 9.1)
    )

    // 5. Linhas da Tabela Desktop (Campanhas, Conjuntos e Anuncios)
    val rows = mutableStateListOf(
        // Campanhas
        AdsRowItem("CMP_101", "act_10492811", "CAMPAIGN", "[ESC] [CBO] Vendas Diretas - Escala 10x", true, "CBO", "VOLUME_MAIS_ALTO", 2500.0, 1840.0, 46, 8648.0, 142, 68400, 1980, 29412, 15048),
        AdsRowItem("CMP_102", "act_10492811", "CAMPAIGN", "[TESTE] [ABO] Validação Criativos Novos", true, "ABO", "COST_CAP", 600.0, 490.0, 4, 780.0, 19, 18200, 310, 4914, 1820),
        AdsRowItem("CMP_103", "act_10492811", "CAMPAIGN", "[RETARGET] [CBO] Funil Quente 7D + IC", true, "CBO", "ROAS_MINIMO", 800.0, 620.0, 22, 3410.0, 64, 19500, 740, 8970, 5265),

        // Conjuntos de Anuncios
        AdsRowItem("ADS_201", "CMP_101", "ADSET", "01 - Aberto Advantage+ [18-55] [Reels/Stories]", true, "CBO", "VOLUME_MAIS_ALTO", 2500.0, 980.0, 28, 5320.0, 84, 36000, 1120, 16920, 9000),
        AdsRowItem("ADS_202", "CMP_101", "ADSET", "02 - Lookalike 1% Compradores Pixel", true, "CBO", "VOLUME_MAIS_ALTO", 2500.0, 860.0, 18, 3328.0, 58, 32400, 860, 12492, 6048),
        AdsRowItem("ADS_203", "CMP_102", "ADSET", "01 - Teste Hook Forte ABO #01", true, "ABO", "COST_CAP", 150.0, 145.0, 0, 0.0, 3, 5400, 62, 1100, 410),

        // Anuncios (Com Post ID e UTMs)
        AdsRowItem("AD_301", "ADS_201", "AD", "AD01 - Vídeo VSL Gancho Curiosidade [Dark Post]", true, "CBO", "VOLUME_MAIS_ALTO", 2500.0, 980.0, 28, 5320.0, 84, 36000, 1120, 16920, 9000, postId = "122148992031_99817263541"),
        AdsRowItem("AD_302", "ADS_202", "AD", "AD02 - Criativo Dinâmico Depoimento [DCO]", true, "CBO", "VOLUME_MAIS_ALTO", 2500.0, 860.0, 18, 3328.0, 58, 32400, 860, 12492, 6048, postId = "122148992031_88471625390")
    )

    // Selecao em Massa (Bulk Engine)
    val selectedRowIds = mutableStateListOf<String>()

    // Filtros da Planilha
    var selectedLevel by mutableStateOf("CAMPAIGN") // CAMPAIGN, ADSET, AD
    var selectedDatePreset by mutableStateOf("Hoje")
    var selectedBreakdown by mutableStateOf("Nenhum") // Nenhum, Idade, Gênero, Posicionamento

    // 6. Central de Publicos
    val audiences = mutableStateListOf(
        CustomAudienceItem("AUD_1", "[PIXEL] Compradores Últimos 180 Dias", "PIXEL", "Purchase (180D)", "48.200 pessoas"),
        CustomAudienceItem("AUD_2", "[PIXEL] Initiate Checkout Não Compradores 14D", "PIXEL", "InitiateCheckout (14D)", "112.500 pessoas"),
        CustomAudienceItem("AUD_3", "[LAL 1%] Semelhante Compradores BRL", "LOOKALIKE", "1% Brasil", "1.640.000 pessoas"),
        CustomAudienceItem("AUD_4", "[VÍDEO 75%] Retenção VSL Principal 30D", "VIDEO", "ThruPlay/75%", "290.000 pessoas")
    )

    // 7. Regras Automatizadas (Piloto Automatico)
    val automatedRules = mutableStateListOf(
        AutomatedRuleItem("RUL_1", "Stop Loss Implacável (Cortar Sangria)", "Se Gasto > R$ 80,00 e Compras = 0 (Hoje)", "Pausar Conjunto de Anúncios imediatamente", true),
        AutomatedRuleItem("RUL_2", "Escala Vertical Surf Scaling (+20%)", "Se ROAS >= 2.5x e Compras >= 3 (Hoje)", "Aumentar Orçamento em +20% (1x a cada 3h)", true),
        AutomatedRuleItem("RUL_3", "Reset de Orçamento da Meia-Noite", "Todos os dias às 23:59", "Voltar conjuntos escalados para o orçamento base", false)
    )

    // --- ACOES DE 1 CLIQUE ---

    fun addFacebookProfile(name: String, token: String) {
        if (name.isBlank()) return
        val newId = "PRF_" + (profiles.size + 1)
        val cleanToken = if (token.isBlank()) "DEMO_TOKEN_$newId" else token.trim()
        val p = FbProfile(newId, name.trim(), cleanToken)
        profiles.add(p)
        selectedProfile = p
        statusBanner = "Perfil '${p.name}' conectado ao Cofre Multi-Login!"
    }

    fun createNewAdAccount1Click(accountName: String, currency: String, timezone: String) {
        if (accountName.isBlank()) return
        viewModelScope.launch {
            statusBanner = "Criando conta '$accountName' na BM e atribuindo permissão de Admin..."
            val res = api.createAdAccountWithAdmin(
                bmId = selectedBm.id,
                accountName = accountName.trim(),
                currency = currency,
                timezoneId = timezone,
                userId = selectedProfile.id,
                accessToken = selectedProfile.accessToken
            )
            val newRawId = res.getOrElse { (10000000..99999999).random().toString() }
            val newAcc = AdAccount(
                id = newRawId,
                actId = "act_$newRawId",
                name = accountName.trim(),
                bmId = selectedBm.id,
                currency = currency,
                timezone = timezone,
                status = "ATIVA (ADMIN ATRIBUÍDO)"
            )
            adAccounts.add(0, newAcc)
            selectedAdAccount = newAcc
            statusBanner = "Conta ${newAcc.actId} criada e vinculada com Admin Total em 1 clique!"
        }
    }

    fun createNewPixel1Click(pixelName: String) {
        if (pixelName.isBlank()) return
        viewModelScope.launch {
            statusBanner = "Criando Pixel '$pixelName' e vinculando à conta ${selectedAdAccount.actId}..."
            val res = api.createAndLinkPixel(
                bmId = selectedBm.id,
                pixelName = pixelName.trim(),
                adAccountId = selectedAdAccount.actId,
                accessToken = selectedProfile.accessToken
            )
            val newId = res.getOrElse { (100000000000000L..999999999999999L).random().toString() }
            val generatedCapi = "EAABsbCS1iHgBO" + (100000..999999).random() + "CAPI_" + newId.takeLast(6)
            val px = AdPixel(
                id = newId,
                name = pixelName.trim(),
                linkedAccountId = selectedAdAccount.actId,
                capiToken = generatedCapi,
                matchQuality = 9.5
            )
            pixels.add(0, px)
            statusBanner = "Pixel $newId criado, vinculado à ${selectedAdAccount.name} e CAPI gerado!"
        }
    }

    fun toggleRowSelection(id: String) {
        if (selectedRowIds.contains(id)) selectedRowIds.remove(id) else selectedRowIds.add(id)
    }

    fun selectAllCurrentLevel() {
        val currentIds = rows.filter { it.level == selectedLevel }.map { it.id }
        if (selectedRowIds.containsAll(currentIds)) {
            selectedRowIds.removeAll(currentIds)
        } else {
            currentIds.forEach { if (!selectedRowIds.contains(it)) selectedRowIds.add(it) }
        }
    }

    fun toggleRowStatus(id: String) {
        val idx = rows.indexOfFirst { it.id == id }
        if (idx >= 0) {
            val item = rows[idx]
            rows[idx] = item.copy(active = !item.active)
        }
    }

    // Duplicacao 1-para-N em Massa (Escala Horizontal)
    fun duplicateSelected1ToN(copiesPerItem: Int) {
        val count = copiesPerItem.coerceIn(1, 50)
        val targets = rows.filter { selectedRowIds.contains(it.id) }
        if (targets.isEmpty()) return

        viewModelScope.launch {
            var totalCreated = 0
            targets.forEach { original ->
                api.duplicateObject1ToN(original.id, count, selectedProfile.accessToken)
                for (i in 1..count) {
                    val newId = original.level.take(3) + "_" + (1000..9999).random()
                    rows.add(
                        0,
                        original.copy(
                            id = newId,
                            name = "${original.name} — Cópia #$i",
                            spend = 0.0,
                            purchases = 0,
                            revenue = 0.0,
                            initiateCheckouts = 0,
                            impressions = 0,
                            linkClicks = 0,
                            video3sViews = 0,
                            thruPlays = 0,
                            active = true
                        )
                    )
                    totalCreated++
                }
            }
            selectedRowIds.clear()
            statusBanner = "Escala Horizontal concluída: $totalCreated novas cópias publicadas!"
        }
    }

    // Edicao de Orcamento em Massa (% ou Valor Fixo)
    fun bulkAdjustBudgetPercent(percentDelta: Double) {
        var updated = 0
        for (i in rows.indices) {
            if (selectedRowIds.contains(rows[i].id)) {
                val oldBudget = rows[i].dailyBudget
                val newBudget = (oldBudget * (1.0 + percentDelta / 100.0)).coerceAtLeast(10.0)
                rows[i] = rows[i].copy(dailyBudget = kotlin.math.round(newBudget * 100.0) / 100.0)
                updated++
            }
        }
        statusBanner = "Orçamento ajustado em ${if (percentDelta > 0) "+$percentDelta%" else "$percentDelta%"} em $updated itens!"
    }

    fun bulkSetStatus(active: Boolean) {
        var updated = 0
        for (i in rows.indices) {
            if (selectedRowIds.contains(rows[i].id)) {
                rows[i] = rows[i].copy(active = active)
                updated++
            }
        }
        statusBanner = "$updated itens alterados para ${if (active) "ATIVO" else "PAUSADO"}!"
    }

    fun bulkUpdateUtms(newUtm: String) {
        if (newUtm.isBlank()) return
        var updated = 0
        for (i in rows.indices) {
            if (selectedRowIds.contains(rows[i].id)) {
                rows[i] = rows[i].copy(utmParams = newUtm.trim())
                updated++
            }
        }
        statusBanner = "UTMs atualizadas em lote em $updated itens!"
    }

    // Criador Completo Desktop em 1 Tela (Com multiplicador 1-N integrado)
    fun publishFullStructure(
        campaignName: String,
        budgetType: String,
        bidStrategy: String,
        dailyBudget: Double,
        adSetName: String,
        adSetCopies: Int,
        adName: String,
        postId: String,
        utmString: String
    ) {
        val cmpId = "CMP_" + (1000..9999).random()
        rows.add(
            0,
            AdsRowItem(
                id = cmpId,
                parentId = selectedAdAccount.actId,
                level = "CAMPAIGN",
                name = campaignName.ifBlank { "[ESC] [$budgetType] Nova Campanha Pro" },
                active = true,
                budgetType = budgetType,
                bidStrategy = bidStrategy,
                dailyBudget = dailyBudget,
                spend = 0.0,
                purchases = 0,
                revenue = 0.0,
                initiateCheckouts = 0,
                impressions = 0,
                linkClicks = 0,
                video3sViews = 0,
                thruPlays = 0,
                postId = postId,
                utmParams = utmString
            )
        )

        val copies = adSetCopies.coerceIn(1, 50)
        for (i in 1..copies) {
            val adSetId = "ADS_" + (1000..9999).random()
            val suffix = if (copies > 1) " #$i" else ""
            rows.add(
                0,
                AdsRowItem(
                    id = adSetId,
                    parentId = cmpId,
                    level = "ADSET",
                    name = (adSetName.ifBlank { "01 - Conjunto Escala" }) + suffix,
                    active = true,
                    budgetType = budgetType,
                    bidStrategy = bidStrategy,
                    dailyBudget = dailyBudget,
                    spend = 0.0,
                    purchases = 0,
                    revenue = 0.0,
                    initiateCheckouts = 0,
                    impressions = 0,
                    linkClicks = 0,
                    video3sViews = 0,
                    thruPlays = 0,
                    postId = postId,
                    utmParams = utmString
                )
            )
            rows.add(
                0,
                AdsRowItem(
                    id = "AD_" + (1000..9999).random(),
                    parentId = adSetId,
                    level = "AD",
                    name = (adName.ifBlank { "AD01 - Criativo Campeão" }) + suffix,
                    active = true,
                    budgetType = budgetType,
                    bidStrategy = bidStrategy,
                    dailyBudget = dailyBudget,
                    spend = 0.0,
                    purchases = 0,
                    revenue = 0.0,
                    initiateCheckouts = 0,
                    impressions = 0,
                    linkClicks = 0,
                    video3sViews = 0,
                    thruPlays = 0,
                    postId = postId,
                    utmParams = utmString
                )
            )
        }
        statusBanner = "Estrutura 1-$copies-$copies publicada com sucesso na conta ${selectedAdAccount.actId}!"
    }

    fun createAudience(name: String, type: String, subtype: String) {
        if (name.isBlank()) return
        audiences.add(
            0,
            CustomAudienceItem(
                id = "AUD_" + (100..999).random(),
                name = name.trim(),
                type = type,
                subtype = subtype,
                sizeEstimate = "Populando via Graph API..."
            )
        )
        statusBanner = "Público '$name' criado na conta ${selectedAdAccount.actId}!"
    }

    fun addAutomatedRule(name: String, condition: String, action: String) {
        if (name.isBlank()) return
        automatedRules.add(
            0,
            AutomatedRuleItem(
                id = "RUL_" + (100..999).random(),
                name = name.trim(),
                conditionText = condition,
                actionText = action,
                enabled = true
            )
        )
        statusBanner = "Regra Automatizada '$name' ativada via API!"
    }

    fun toggleRule(id: String) {
        val idx = automatedRules.indexOfFirst { it.id == id }
        if (idx >= 0) {
            val r = automatedRules[idx]
            automatedRules[idx] = r.copy(enabled = !r.enabled)
        }
    }
}
