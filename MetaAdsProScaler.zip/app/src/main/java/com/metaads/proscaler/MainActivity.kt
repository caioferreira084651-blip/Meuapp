package com.metaads.proscaler

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.lifecycle.viewmodel.compose.viewModel
import com.metaads.proscaler.ui.MetaAdsProApp
import com.metaads.proscaler.viewmodel.MetaViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val vm: MetaViewModel = viewModel()
            MetaAdsProApp(vm = vm)
        }
    }
}
