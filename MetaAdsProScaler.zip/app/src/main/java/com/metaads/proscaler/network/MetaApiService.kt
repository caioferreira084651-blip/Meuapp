package com.metaads.proscaler.network

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.FormBody
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class MetaApiService {
    private val client = OkHttpClient.Builder()
        .connectTimeout(25, TimeUnit.SECONDS)
        .readTimeout(25, TimeUnit.SECONDS)
        .build()

    private val baseUrl = "https://graph.facebook.com/v21.0"

    // 1. Criar Nova Conta de Anuncio na BM + Atribuir Admin Automaticamente (1 Clique)
    suspend fun createAdAccountWithAdmin(
        bmId: String,
        accountName: String,
        currency: String,
        timezoneId: String,
        userId: String,
        accessToken: String
    ): Result<String> = withContext(Dispatchers.IO) {
        try {
            if (accessToken.isBlank() || accessToken.startsWith("DEMO")) {
                val generatedId = (100000000..999999999).random().toString()
                return@withContext Result.success(generatedId)
            }
            val createBody = FormBody.Builder()
                .add("name", accountName)
                .add("currency", currency)
                .add("timezone_id", "25") // America/Sao_Paulo
                .add("end_advertiser", bmId)
                .add("media_agency", "NONE")
                .add("partner", "NONE")
                .add("access_token", accessToken)
                .build()

            val createReq = Request.Builder()
                .url("$baseUrl/$bmId/adaccount")
                .post(createBody)
                .build()

            client.newCall(createReq).execute().use { resp ->
                val bodyStr = resp.body?.string().orEmpty()
                if (!resp.isSuccessful) {
                    return@withContext Result.failure(Exception("Erro Graph API: $bodyStr"))
                }
                val json = JSONObject(bodyStr)
                val rawActId = json.optString("id", "").removePrefix("act_")

                // Automacao Encadeada: Atribuir permissao total de Administrador ao usuario
                if (userId.isNotBlank() && rawActId.isNotBlank()) {
                    val assignBody = FormBody.Builder()
                        .add("user", userId)
                        .add("tasks", "[\"MANAGE\",\"ADVERTISE\",\"ANALYZE\"]")
                        .add("access_token", accessToken)
                        .build()
                    val assignReq = Request.Builder()
                        .url("$baseUrl/act_$rawActId/assigned_users")
                        .post(assignBody)
                        .build()
                    client.newCall(assignReq).execute().close()
                }
                Result.success(rawActId)
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // 2. Criar Novo Pixel na BM + Vincular Automaticamente a Conta de Anuncio
    suspend fun createAndLinkPixel(
        bmId: String,
        pixelName: String,
        adAccountId: String,
        accessToken: String
    ): Result<String> = withContext(Dispatchers.IO) {
        try {
            if (accessToken.isBlank() || accessToken.startsWith("DEMO")) {
                val newPixelId = (100000000000000L..999999999999999L).random().toString()
                return@withContext Result.success(newPixelId)
            }
            val createBody = FormBody.Builder()
                .add("name", pixelName)
                .add("access_token", accessToken)
                .build()
            val req = Request.Builder()
                .url("$baseUrl/$bmId/adspixels")
                .post(createBody)
                .build()

            client.newCall(req).execute().use { resp ->
                val str = resp.body?.string().orEmpty()
                if (!resp.isSuccessful) {
                    return@withContext Result.failure(Exception("Erro ao criar Pixel: $str"))
                }
                val pixelId = JSONObject(str).optString("id")

                // Vincular automaticamente a conta de anuncios selecionada
                val shareBody = FormBody.Builder()
                    .add("account_id", adAccountId.removePrefix("act_"))
                    .add("business", bmId)
                    .add("access_token", accessToken)
                    .build()
                val shareReq = Request.Builder()
                    .url("$baseUrl/$pixelId/shared_accounts")
                    .post(shareBody)
                    .build()
                client.newCall(shareReq).execute().close()

                Result.success(pixelId)
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // 3. Duplicacao 1-para-N via API Oficial (/copies)
    suspend fun duplicateObject1ToN(
        objectId: String,
        copiesCount: Int,
        accessToken: String
    ): Result<Int> = withContext(Dispatchers.IO) {
        try {
            if (accessToken.isBlank() || accessToken.startsWith("DEMO")) {
                return@withContext Result.success(copiesCount)
            }
            var created = 0
            for (i in 1..copiesCount) {
                val form = FormBody.Builder()
                    .add("deep_copy", "true")
                    .add("status_option", "ACTIVE")
                    .add("access_token", accessToken)
                    .build()
                val req = Request.Builder()
                    .url("$baseUrl/$objectId/copies")
                    .post(form)
                    .build()
                client.newCall(req).execute().use { r ->
                    if (r.isSuccessful) created++
                }
            }
            Result.success(created)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
